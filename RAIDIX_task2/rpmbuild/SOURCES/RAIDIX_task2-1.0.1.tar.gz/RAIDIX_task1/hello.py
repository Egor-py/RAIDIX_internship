import sys

sys.stdout.write('Test task in RAIDIX!\n')
